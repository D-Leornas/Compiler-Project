abstract class Stmt extends Token implements TI {
	
}

