abstract class NonWhileStmt extends NonIfStmt implements TI {

	abstract public String toString(int t);
}

