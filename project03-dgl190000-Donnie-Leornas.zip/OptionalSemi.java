class OptionalSemi extends Token implements TI {

	public OptionalSemi()
	{
		
	}

	public String toString(int t)
	{
		return "";
	}

	public String typeCheck() throws CompProjException {
        return "semi";
    }

}
