class PrintLnList extends Token implements TI {
    public PrintLnList()
    {

    }

    public String toString(int t)
    {
    	return "";
    }

    public String typeCheck() throws CompProjException {
        return "";
    }
}
