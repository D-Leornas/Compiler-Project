abstract class NonIfStmt extends Stmt implements TI {

	abstract public String toString(int t);
}

