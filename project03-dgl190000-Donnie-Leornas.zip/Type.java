abstract class Type extends ReturnType implements TI {


}
