abstract class FuncStmt extends NonWhileStmt implements TI {
	String id;
	public FuncStmt(String i)
	{
		id = i;
	}
}
