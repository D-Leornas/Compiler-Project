class OptionalFinal extends Token implements TI {

	public OptionalFinal()
	{

	}

	public String toString(int t)
	{
		return "";
	}

	public String typeCheck() throws CompProjException {
        return "final";
    }

}
