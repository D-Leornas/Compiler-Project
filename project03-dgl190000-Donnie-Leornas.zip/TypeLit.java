abstract class TypeLit extends Expr implements TI {

}

