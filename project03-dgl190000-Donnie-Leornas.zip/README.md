Output files are in the testsOut folder

"make run" command runs all of the input files in the testsIn folder and outputs to the testOut folder.