abstract class FuncExpr extends Expr implements TI{
	String id;
	public FuncExpr(String i)
	{
		id = i;
	}
}
