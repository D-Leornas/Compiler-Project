abstract class ReturnType extends Token implements TI {

}
